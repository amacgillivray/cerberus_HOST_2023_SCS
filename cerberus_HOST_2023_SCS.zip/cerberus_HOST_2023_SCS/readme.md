# SUBMISSION - CERBERUS

 - The report is provided in this folder at report.pdf
 - Code is provided at https://github.com/amacgillivray/cerberus_HOST_2023_SCS
 - Code without data is also available in "code_nodata" in this directory
 - Sample submission is in "sample_submission.csv"
 - The demo is provided at https://youtu.be/JxXAU5iE-uA
 - The presentation is provided in this folder, as both a powerpoint and PDF: 
   - presentation.pptx
   - presentation.pdf
